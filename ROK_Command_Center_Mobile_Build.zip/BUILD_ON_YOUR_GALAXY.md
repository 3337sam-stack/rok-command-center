# Build the APK using only your Samsung Galaxy

This project can be built in GitHub's cloud from the phone browser. No PC is required.
You need an internet connection and a free GitHub account.

## Steps

1. On your Galaxy, open https://github.com and sign in (or create an account).
2. Create a new repository named `rok-command-center`. Choose **Public** for the simplest free Actions setup, or use a private repository if your account allows Actions for it.
3. On the repository page, choose **Add file → Upload files**.
4. Extract `ROK_Command_Center_Mobile_Build.zip` using Samsung My Files (tap the ZIP, then Extract).
5. Upload all extracted project contents to the repository root. Make sure the `.github/workflows/build-apk.yml` file is included. If the GitHub mobile page makes hidden `.github` folders difficult to upload, use GitHub's web interface in Chrome with **Desktop site** enabled.
6. Commit the files to the `main` branch.
7. Open the repository's **Actions** tab. Select **Build ROK Command Center APK** and tap **Run workflow** if it has not started automatically.
8. Wait for the workflow to finish with a green check mark.
9. Open the completed workflow run, scroll to **Artifacts**, and download `ROK-Command-Center-debug`.
10. Extract that downloaded ZIP in My Files. Tap `app-debug.apk` and allow installation from this source if Android asks.

## Important

- This produces a debug APK for testing, not a Play Store release.
- The current app is a UI prototype. It uses sample march data; it does not yet read Rise of Kingdoms or automate game actions.
- Do not upload signing keys, passwords, or personal game credentials.
