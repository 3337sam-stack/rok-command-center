package com.rokcommandcenter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF101923)
private val Panel = Color(0xFF1B2935)
private val Accent = Color(0xFF58C69A)
private val Muted = Color(0xFFAAB7C2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RokApp() }
    }
}

data class March(val number: Int, val resource: String, val status: String, val commander: String)

@Composable
fun RokApp() {
    var selected by remember { mutableStateOf("Dashboard") }
    var gemPriority by remember { mutableStateOf(true) }
    var resourcePriority by remember { mutableStateOf(false) }
    var marches by remember {
        mutableStateOf(
            listOf(
                March(1, "Food", "Gathering", "Not assigned"),
                March(2, "Wood", "Gathering", "Not assigned"),
                March(3, "Gems", "Available", "Not assigned"),
                March(4, "Stone", "Available", "Not assigned"),
                March(5, "Gold", "Available", "Not assigned")
            )
        )
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, background = Navy, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    val tabs = listOf("Dashboard", "Commanders", "Marches", "Settings")
                    val icons = listOf(Icons.Default.Dashboard, Icons.Default.Groups, Icons.Default.Route, Icons.Default.Settings)
                    tabs.forEachIndexed { index, tab ->
                        NavigationBarItem(
                            selected = selected == tab,
                            onClick = { selected = tab },
                            icon = { Icon(icons[index], contentDescription = tab) },
                            label = { Text(tab, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ROK COMMAND CENTER", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                        Text("Smart Gathering Assistant", color = Muted, fontSize = 12.sp)
                    }
                    Surface(color = Color(0xFF173D32), shape = RoundedCornerShape(50)) {
                        Text("SAFE MODE", color = Accent, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(18.dp))
                when (selected) {
                    "Dashboard" -> Dashboard(marches, gemPriority)
                    "Commanders" -> CommandersScreen()
                    "Marches" -> MarchesScreen(marches) { index ->
                        marches = marches.mapIndexed { i, m ->
                            if (i == index) m.copy(status = if (m.status == "Available") "Gathering" else "Available") else m
                        }
                    }
                    else -> SettingsScreen(gemPriority, { gemPriority = it }, resourcePriority, { resourcePriority = it })
                }
            }
        }
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Panel, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(value, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun Dashboard(marches: List<March>, gemPriority: Boolean) {
    val active = marches.count { it.status == "Gathering" || it.status == "Returning" }
    val available = marches.count { it.status == "Available" }
    Text("Overview", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatCard("Active marches", active.toString(), Modifier.weight(1f))
        StatCard("Available", available.toString(), Modifier.weight(1f))
        StatCard("Total marches", marches.size.toString(), Modifier.weight(1f))
    }
    Spacer(Modifier.height(18.dp))
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Diamond, contentDescription = null, tint = Accent)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Gem priority", color = Color.White, fontWeight = FontWeight.Medium)
                Text(if (gemPriority) "Prioritize gem nodes in recommendations" else "Normal resource recommendations", color = Muted, fontSize = 11.sp)
            }
            Text(if (gemPriority) "ON" else "OFF", color = Accent, fontWeight = FontWeight.Bold)
        }
    }
    Spacer(Modifier.height(18.dp))
    Text("March status", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(8.dp))
    marches.forEach { MarchRow(it) }
    Spacer(Modifier.height(12.dp))
    Text("This is a local prototype. March data is currently sample data and is not read from the game.", color = Muted, fontSize = 11.sp)
}

@Composable
fun MarchRow(march: March) {
    Surface(color = Panel, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                when (march.resource) {
                    "Gems" -> Icons.Default.Diamond
                    "Food" -> Icons.Default.Agriculture
                    "Wood" -> Icons.Default.Forest
                    "Stone" -> Icons.Default.Landscape
                    else -> Icons.Default.MonetizationOn
                }, contentDescription = null, tint = Accent
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("March ${march.number} · ${march.resource}", color = Color.White, fontWeight = FontWeight.Medium)
                Text(march.commander, color = Muted, fontSize = 11.sp)
            }
            Text(march.status, color = if (march.status == "Available") Accent else Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun CommandersScreen() {
    Text("Commander database", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    Text("Add your gathering commanders and their skills in the next data-entry build.", color = Muted, fontSize = 12.sp)
    Spacer(Modifier.height(12.dp))
    listOf("Constance", "Sarka", "Gaius Marius", "Joan of Arc", "Cleopatra").forEach {
        Surface(color = Panel, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Person, contentDescription = null, tint = Accent)
                Spacer(Modifier.width(10.dp))
                Text(it, color = Color.White)
                Spacer(Modifier.weight(1f))
                Text("Not configured", color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun MarchesScreen(marches: List<March>, onToggle: (Int) -> Unit) {
    Text("March manager", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    Text("Manual status controls for prototype testing", color = Muted, fontSize = 12.sp)
    Spacer(Modifier.height(10.dp))
    marches.forEachIndexed { index, march ->
        Surface(color = Panel, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("March ${march.number} · ${march.resource}", color = Color.White, fontWeight = FontWeight.Medium)
                    Text("Status: ${march.status}", color = Muted, fontSize = 11.sp)
                }
                OutlinedButton(onClick = { onToggle(index) }) {
                    Text(if (march.status == "Available") "Mark active" else "Mark available")
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(gem: Boolean, onGem: (Boolean) -> Unit, resource: Boolean, onResource: (Boolean) -> Unit) {
    Text("Settings", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(8.dp))
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Gem priority", color = Color.White)
                    Text("Recommend gem gathering before regular resources", color = Muted, fontSize = 11.sp)
                }
                Switch(checked = gem, onCheckedChange = onGem)
            }
            Divider(color = Color(0xFF354653), modifier = Modifier.padding(vertical = 8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Resource priority", color = Color.White)
                    Text("Prefer regular resource nodes", color = Muted, fontSize = 11.sp)
                }
                Switch(checked = resource, onCheckedChange = onResource)
            }
        }
    }
    Spacer(Modifier.height(14.dp))
    Text("Version 0.1.0 · Android 12+", color = Muted, fontSize = 11.sp)
    Text("Safe companion only. No game automation or direct game control.", color = Muted, fontSize = 11.sp)
}
