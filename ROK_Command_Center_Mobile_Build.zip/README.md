# ROK Command Center — Android starter project

English-language Android companion app prototype for Samsung Galaxy S21 Ultra (Android 12).

## Current prototype features
- Dashboard with sample march status
- Commander roster placeholder
- Manual march status toggles
- Gem and resource priority settings
- Safe-mode labeling

## Important limitations
This is a starter source project, not a compiled APK. It does not connect to Rise of Kingdoms, inspect game memory/network traffic, or automate taps. The displayed march data is sample data and is not persistent yet.

## Build
1. Install Android Studio (a current stable release) on a computer.
2. Open this folder as an existing Gradle project.
3. Install Android SDK Platform 35 and JDK 17 when prompted.
4. Sync Gradle.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Install the generated debug APK on the Galaxy S21 Ultra.

Minimum Android version: 12 (API 31).
Target SDK: 35.

## Planned next development steps
1. Persistent commander and march records using Room.
2. User-entered commander skills and gathering specializations.
3. Screenshot import and OCR-assisted status extraction with user confirmation.
4. Local timers and notifications, subject to Android background-execution limits.
